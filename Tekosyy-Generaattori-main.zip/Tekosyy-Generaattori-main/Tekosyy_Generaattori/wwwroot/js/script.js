const userCardTemplate = document.querySelector("[data-user-template]")
const dataUsersContainer = document.querySelector("[data-users-container]")
const SearchInput = document.querySelector("[data-search]")

let users = []

SearchInput.addEventListener("input", e => {
    const value = e.target.value.toLowerCase()
    users.forEach(user => {
        const isVisible = user.user.toLowerCase().includes(value)
        user.element.class.List.toggle("hide", !isVisible)
    })
})

fetch('database.db')
    .then(res => res.json())
    .then(data => {
        user = data.map(user => {
            const card = userCardTemplate.content.cloneNode(true).children[0]
            const header = card.querySelector("[data.header]")
            const body = card.querySelector("[data.body]")
            header.textContent = user.user
            body.textContent = user.password
            dataUsersContainer.append(card)
            return { username: user.user, password: user.password, element: card }
        })
    })
