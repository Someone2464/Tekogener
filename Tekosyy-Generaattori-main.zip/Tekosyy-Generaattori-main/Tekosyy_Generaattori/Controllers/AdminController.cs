using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

[ApiController]
[Route("api/[controller]")]
public class AdminController : ControllerBase
{
    private readonly AdminService _adminService;

    public AdminController(AdminService adminService)
    {
        _adminService = adminService;
    }

    // GET: api/admin
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AdminDto>>> GetAdmins()
    {
        var admins = await _adminService.GetAllAdminsAsync();
        return Ok(admins);
    }

    // GET: api/admin/{username}
    [HttpGet("{username}")]
    public async Task<ActionResult<AdminDto>> GetAdmin(string username)
    {
        var result = await _adminService.FindAdminAsync(username);
        if (!result.Success)
        {
            return NotFound(new { message = result.Message });
        }
        return Ok(new AdminDto { Username = result.Admin.Username });
    }

    // POST: api/admin
    [HttpPost]
    public async Task<ActionResult<AdminDto>> CreateAdmin([FromBody] CreateAdminDto adminDto)
    {
        if (string.IsNullOrEmpty(adminDto.Username) || string.IsNullOrEmpty(adminDto.Password))
        {
            return BadRequest(new { message = "Username and password cannot be empty" });
        }

        var result = await _adminService.AddAdminAsync(adminDto.Username, adminDto.Password);
        if (!result.Success)
        {
            return Conflict(new { message = result.Message });
        }

        return CreatedAtAction(nameof(GetAdmin), new { username = adminDto.Username },
            new AdminDto { Username = adminDto.Username });
    }

    // PUT: api/admin/{username}
    [HttpPut("{username}")]
    public async Task<IActionResult> UpdateAdmin(string username, [FromBody] UpdateAdminDto adminDto)
    {
        if (string.IsNullOrEmpty(username))
        {
            return BadRequest(new { message = "Username cannot be empty" });
        }

        var result = await _adminService.UpdateAdminAsync(username, adminDto.Password);
        if (!result.Success)
        {
            if (result.Message.Contains("not found"))
            {
                return NotFound(new { message = result.Message });
            }
            return BadRequest(new { message = result.Message });
        }

        return NoContent();
    }

    // DELETE: api/admin/{username}
    [HttpDelete("{username}")]
    public async Task<IActionResult> DeleteAdmin(string username)
    {
        var result = await _adminService.DeleteAdminAsync(username);
        if (!result.Success)
        {
            if (result.Message.Contains("not found"))
            {
                return NotFound(new { message = result.Message });
            }
            return BadRequest(new { message = result.Message });
        }

        return NoContent();
    }
}

// DTOs
public class AdminDto
{
    public string Username { get; set; }
}

public class CreateAdminDto
{
    public string Username { get; set; }
    public string Password { get; set; }
}

public class UpdateAdminDto
{
    public string Password { get; set; }
}