using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

[ApiController]
[Route("api/[controller]")]
public class TekosyyController : ControllerBase
{
    private readonly TekosyyService _tekosyyService;

    public TekosyyController(TekosyyService tekosyyService)
    {
        _tekosyyService = tekosyyService;
    }

    // GET: api/tekosyy
    [HttpGet]
    public async Task<ActionResult<IEnumerable<TekosyyDto>>> GetAll()
    {
        var tekosyyt = await _tekosyyService.GetAllTekosyytAsync();
        return Ok(tekosyyt);
    }

    // GET: api/tekosyy/{id}
    [HttpGet("{id}")]
    public async Task<ActionResult<TekosyyDto>> GetById(int id)
    {
        var result = await _tekosyyService.GetTekosyyByIdAsync(id);
        if (!result.Success)
        {
            return NotFound(new { message = result.Message });
        }
        return Ok(result.Tekosyy);
    }

    // POST: api/tekosyy
    [HttpPost]
    public async Task<ActionResult<TekosyyDto>> Create([FromBody] CreateTekosyyDto tekosyyDto)
    {
        if (string.IsNullOrEmpty(tekosyyDto.Tekosyy) || string.IsNullOrEmpty(tekosyyDto.Tyyppi))
        {
            return BadRequest(new { message = "Tekosyy and tyyppi cannot be empty" });
        }

        var result = await _tekosyyService.AddTekosyyAsync(
            tekosyyDto.Tekosyy,
            tekosyyDto.UserId,
            tekosyyDto.Tyyppi,
            tekosyyDto.AchievementPoints  // Pass the achievement points
        );

        if (!result.Success)
        {
            return BadRequest(new { message = result.Message });
        }

        return CreatedAtAction(nameof(GetById), new { id = result.Tekosyy.Id }, result.Tekosyy);
    }

    // PUT: api/tekosyy/{id}
    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateTekosyyDto tekosyyDto)
    {
        if (id != tekosyyDto.Id)
        {
            return BadRequest(new { message = "ID mismatch" });
        }

        var result = await _tekosyyService.UpdateTekosyyAsync(id, tekosyyDto.Tekosyy, tekosyyDto.Tyyppi);
        if (!result.Success)
        {
            if (result.Message.Contains("not found"))
            {
                return NotFound(new { message = result.Message });
            }
            return BadRequest(new { message = result.Message });
        }

        return NoContent();
    }

    // DELETE: api/tekosyy/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _tekosyyService.DeleteTekosyyAsync(id);
        if (!result.Success)
        {
            if (result.Message.Contains("not found"))
            {
                return NotFound(new { message = result.Message });
            }
            return BadRequest(new { message = result.Message });
        }

        return NoContent();
    }
}

// Data Transfer Objects
public class TekosyyDto
{
    public int Id { get; set; }
    public string Tekosyy { get; set; }
    public int UserId { get; set; }
    public int AchievementPoints { get; set; }
    public string Tyyppi { get; set; }
}

public class CreateTekosyyDto
{
    public string Tekosyy { get; set; }
    public int UserId { get; set; }
    public string Tyyppi { get; set; }
    public int AchievementPoints { get; set; } = 0; // Add this property
}

public class UpdateTekosyyDto
{
    public int Id { get; set; }
    public string Tekosyy { get; set; }
    public string Tyyppi { get; set; }
}