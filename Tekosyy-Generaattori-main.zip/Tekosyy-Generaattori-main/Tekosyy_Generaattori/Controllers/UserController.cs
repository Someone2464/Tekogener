using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Threading.Tasks;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly UserService _userService;

    public UserController(UserService userService)
    {
        _userService = userService;
    }

    // GET: api/user
    [HttpGet]
    public async Task<ActionResult<IEnumerable<UserDto>>> GetUsers()
    {
        var users = await _userService.GetAllUsersAsync();
        return Ok(users);
    }

    // GET: api/user/{username}
    [HttpGet("{username}")]
    public async Task<ActionResult<UserDto>> GetUser(string username)
    {
        var result = await _userService.FindUserAsync(username);
        if (!result.Success)
        {
            return NotFound(new { message = result.Message });
        }
        return Ok(new UserDto { Id = result.User.Id, Username = result.User.Username });
    }

    // GET: api/user/{username}/id
    [HttpGet("{username}/id")]
    public async Task<ActionResult<int>> GetUserId(string username)
    {
        try
        {
            var result = await _userService.GetUserIdAsync(username);
            if (!result.Success)
            {
                return NotFound(new { message = result.Message });
            }

            return Ok(result.UserId);
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = $"An error occurred: {ex.Message}" });
        }
    }

    // POST: api/user
    [HttpPost]
    public async Task<ActionResult<UserDto>> CreateUser([FromBody] CreateUserDto userDto)
    {
        if (string.IsNullOrEmpty(userDto.Username) || string.IsNullOrEmpty(userDto.Password))
        {
            return BadRequest(new { message = "Username and password cannot be empty" });
        }

        var result = await _userService.AddUserAsync(userDto.Username, userDto.Password);
        if (!result.Success)
        {
            return Conflict(new { message = result.Message });
        }

        return CreatedAtAction(nameof(GetUser), new { username = userDto.Username },
            new UserDto { Id = result.User.Id, Username = userDto.Username });
    }

    // PUT: api/user/{username}
    [HttpPut("{username}")]
    public async Task<IActionResult> UpdateUser(string username, [FromBody] UpdateUserDto updateUserDto)
    {
        if (string.IsNullOrEmpty(username) || updateUserDto == null)
        {
            return BadRequest(new { message = "Invalid input data" });
        }

        var result = await _userService.UpdateUserAsync(username, updateUserDto.Password);
        if (!result.Success)
        {
            if (result.Message.Contains("not found"))
            {
                return NotFound(new { message = result.Message });
            }
            return BadRequest(new { message = result.Message });
        }

        return NoContent();
    }

    // DELETE: api/user/{username}
    [HttpDelete("{username}")]
    public async Task<IActionResult> DeleteUser(string username)
    {
        var result = await _userService.DeleteUserAsync(username);
        if (!result.Success)
        {
            if (result.Message.Contains("not found"))
            {
                return NotFound(new { message = result.Message });
            }
            return BadRequest(new { message = result.Message });
        }

        return NoContent();
    }
}

// Data Transfer Objects
public class UserDto
{
    public int Id { get; set; }
    public string Username { get; set; }
}

public class CreateUserDto
{
    public string Username { get; set; }
    public string Password { get; set; }
}

public class UpdateUserDto
{
    public string Password { get; set; }
}