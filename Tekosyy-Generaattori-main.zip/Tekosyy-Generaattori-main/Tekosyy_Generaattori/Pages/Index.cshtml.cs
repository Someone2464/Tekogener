using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

public class IndexModel : PageModel
{
    private readonly UserService _userService;

    public IndexModel(UserService userService)
    {
        _userService = userService;
    }

    [BindProperty]
    public string NewUsername { get; set; }

    [BindProperty]
    public string NewPassword { get; set; }

    public string UserCreationMessage { get; set; }

    public IActionResult OnPostCreateUser()
    {
        if (string.IsNullOrEmpty(NewUsername) || string.IsNullOrEmpty(NewPassword))
        {
            UserCreationMessage = "Username and password cannot be empty.";
            return Page();
        }

        bool isSuccess = _userService.AddUser(NewUsername, NewPassword);

        if (isSuccess)
        {
            return RedirectToPage("/Login"); // ✅ Redirect to Login
        }
        else
        {
            UserCreationMessage = "Error: Username already exists.";
            return Page();
        }
    }
}
