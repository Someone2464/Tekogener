using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Tekosyy_Generaattori.Pages
{
    public class AdminDashboardModel : PageModel
    {
        private readonly AdminService _adminService;
        private readonly UserService _userService;

        public AdminDashboardModel(AdminService adminService, UserService userService)
        {
            _adminService = adminService;
            _userService = userService;
            
            // Initialize properties to prevent null reference warnings
            NewUsername = string.Empty;
            NewPassword = string.Empty;
            Admins = new List<AdminDto>();
        }

        [BindProperty]
        public string NewUsername { get; set; }

        [BindProperty]
        public string NewPassword { get; set; }

        public List<AdminDto> Admins { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            // Check if user is authenticated and is admin
            if (HttpContext.Session.GetString("IsAdmin") != "true")
            {
                // User is not logged in as admin, redirect to the previous page or home
                string referer = Request.Headers["Referer"].ToString();
                if (string.IsNullOrEmpty(referer) || referer.Contains("/AdminDashboard"))
                {
                    // If no referer or we're already on AdminDashboard, redirect to home
                    return RedirectToPage("/TekosyyGeneraattori");
                }
                else
                {
                    // Redirect back to the page they were on
                    return Redirect(referer);
                }
            }
            
            Admins = new List<AdminDto>(await _adminService.GetAllAdminsAsync());
            return Page();
        }

        public async Task<IActionResult> OnPostAddUserAsync()
        {
            // Check admin authentication before processing
            if (HttpContext.Session.GetString("IsAdmin") != "true")
            {
                // If not admin, redirect to home
                return RedirectToPage("/TekosyyGeneraattori");
            }

            if (string.IsNullOrEmpty(NewUsername) || string.IsNullOrEmpty(NewPassword))
            {
                ModelState.AddModelError(string.Empty, "Username and password cannot be empty.");
                return await OnGetAsync();
            }

            var result = await _userService.AddUserAsync(NewUsername, NewPassword);
            if (!result.Success)
            {
                ModelState.AddModelError(string.Empty, result.Message);
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteAdminAsync(string username)
        {
            // Check admin authentication before processing
            if (HttpContext.Session.GetString("IsAdmin") != "true")
            {
                // If not admin, redirect to home
                return RedirectToPage("/Login");
            }

            if (string.IsNullOrEmpty(username))
            {
                ModelState.AddModelError(string.Empty, "Invalid admin username.");
                return await OnGetAsync();
            }

            var result = await _adminService.DeleteAdminAsync(username);
            if (!result.Success)
            {
                ModelState.AddModelError(string.Empty, result.Message);
            }

            return RedirectToPage();
        }
        
        public IActionResult OnPostLogoutAsync()
        {
            // Clear all session data
            HttpContext.Session.Clear();
            
            // Redirect to the logout page instead of login
            return RedirectToPage("/Logout");
        }
    }
}