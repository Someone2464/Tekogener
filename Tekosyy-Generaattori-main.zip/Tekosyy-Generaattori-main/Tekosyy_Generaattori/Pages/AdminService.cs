using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

public class AdminService
{
    private readonly string _connectionString = "Data Source=database.db;Version=3;";
    private readonly ILogger<AdminService> _logger;

    public AdminService(ILogger<AdminService> logger)
    {
        _logger = logger;
    }

    public async Task<AdminResult> AddAdminAsync(string username, string password)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();

                string insertQuery = "INSERT INTO Admins (user, password) VALUES (@user, @password)";
                using (var command = new SQLiteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@user", username);
                    command.Parameters.AddWithValue("@password", password);

                    await command.ExecuteNonQueryAsync();
                    return new AdminResult { Success = true };
                }
            }
        }
        catch (SQLiteException ex)
        {
            _logger.LogError($"Error adding admin: {ex.Message}");
            return new AdminResult { Success = false, Message = "Username already exists or database error" };
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error adding admin: {ex.Message}");
            return new AdminResult { Success = false, Message = $"An error occurred: {ex.Message}" };
        }
    }

    public async Task<AdminResult> FindAdminAsync(string username)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();
                string query = "SELECT * FROM Admins WHERE user = @username";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return new AdminResult
                            {
                                Success = true,
                                Admin = new Admin
                                {
                                    Username = reader["user"].ToString(),
                                }
                            };
                        }
                        else
                        {
                            return new AdminResult { Success = false, Message = "Admin not found" };
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error finding admin: {ex.Message}");
            return new AdminResult { Success = false, Message = $"An error occurred: {ex.Message}" };
        }
    }

    public async Task<IEnumerable<AdminDto>> GetAllAdminsAsync()
    {
        var admins = new List<AdminDto>();

        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();
                string query = "SELECT user FROM Admins";

                using (var command = new SQLiteCommand(query, connection))
                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        admins.Add(new AdminDto
                        {
                            Username = reader["user"].ToString()
                        });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error retrieving admins: {ex.Message}");
        }

        return admins;
    }

    public async Task<AdminResult> UpdateAdminAsync(string username, string newPassword)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Tarkista ensin onko admin olemassa
                string checkQuery = "SELECT COUNT(*) FROM Admins WHERE user = @username";
                using (var checkCommand = new SQLiteCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@username", username);
                    int exists = Convert.ToInt32(await checkCommand.ExecuteScalarAsync());

                    if (exists == 0)
                    {
                        return new AdminResult { Success = false, Message = "Admin not found" };
                    }
                }

                string updateQuery = "UPDATE Admins SET password = @password WHERE user = @username";
                using (var command = new SQLiteCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", newPassword);

                    await command.ExecuteNonQueryAsync();
                    return new AdminResult { Success = true };
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error updating admin: {ex.Message}");
            return new AdminResult { Success = false, Message = $"An error occurred: {ex.Message}" };
        }
    }

    public async Task<AdminResult> DeleteAdminAsync(string username)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Tarkista ensin onko admin olemassa
                string checkQuery = "SELECT COUNT(*) FROM Admins WHERE user = @username";
                using (var checkCommand = new SQLiteCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@username", username);
                    int exists = Convert.ToInt32(await checkCommand.ExecuteScalarAsync());

                    if (exists == 0)
                    {
                        return new AdminResult { Success = false, Message = "Admin not found" };
                    }
                }

                string deleteQuery = "DELETE FROM Admins WHERE user = @username";
                using (var command = new SQLiteCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@username", username);

                    await command.ExecuteNonQueryAsync();
                    return new AdminResult { Success = true };
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error deleting admin: {ex.Message}");
            return new AdminResult { Success = false, Message = $"An error occurred: {ex.Message}" };
        }
    }

    public bool ValidateAdmin(string username, string password)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM Admins WHERE user = @user AND password = @password";

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@user", username);
                    command.Parameters.AddWithValue("@password", password);

                    int adminExists = Convert.ToInt32(command.ExecuteScalar());
                    return adminExists > 0;
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error validating admin: {ex.Message}");
            return false;
        }
    }

    public class AdminResult
    {
        public bool Success { get; set; }
        public Admin Admin { get; set; }
        public string Message { get; set; }
    }

    public class Admin
    {
        public string Username { get; set; }
    }
}