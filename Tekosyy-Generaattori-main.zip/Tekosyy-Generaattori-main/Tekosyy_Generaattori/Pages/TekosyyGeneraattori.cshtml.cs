using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Http.Features;

public class TekosyyGeneraattoriModel : PageModel
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly ILogger<TekosyyGeneraattoriModel> _logger;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public TekosyyGeneraattoriModel(
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<TekosyyGeneraattoriModel> logger,
        IHttpContextAccessor httpContextAccessor)
    {
        _httpClientFactory = httpClientFactory;
        _configuration = configuration;
        _logger = logger;
        _httpContextAccessor = httpContextAccessor;
    }

    [BindProperty]
    public string Username { get; set; }

    [BindProperty]
    public string UserInput { get; set; } // User input text

    [TempData]
    public string AIResponse { get; set; } // Gemini AI response

    [TempData]
    public string TekosyyMessage { get; set; } // Message about tekosyy saving

    public IActionResult OnGet()
    {
        Username = HttpContext.Session.GetString("Username");
        if (string.IsNullOrEmpty(Username))
        {
            // If session is lost somehow, redirect to login
            return RedirectToPage("/Login");
        }
        // TempData properties (UserInput, AIResponse, TekosyyMessage)
        // are automatically loaded before this method executes.
        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        // Check for both session variables for better compatibility
        string user = HttpContext.Session.GetString("User");
        string username = HttpContext.Session.GetString("Username");

        // If neither is set, redirect to login
        if (string.IsNullOrEmpty(user) && string.IsNullOrEmpty(username))
        {
            return RedirectToPage("/Login");
        }

        // Use whichever session variable is available
        Username = user ?? username;

        string responseMessage;
        if (!string.IsNullOrEmpty(UserInput))
        {
            responseMessage = await GetGeminiAIResponse(UserInput);
        }
        else
        {
            responseMessage = "Please enter some text before submitting.";
        }

        // Store results in TempData before redirecting
        AIResponse = responseMessage;
        TekosyyMessage = null; // Clear any previous save message
        // UserInput is already bound and marked with [TempData]

        return RedirectToPage(); // Redirect after POST
    }

    public async Task<IActionResult> OnPostSaveTekosyyAsync(string tekosyyText)
    {
        Username = HttpContext.Session.GetString("Username");
        if (string.IsNullOrEmpty(Username))
        {
            return RedirectToPage("/Login");
        }

        if (string.IsNullOrEmpty(tekosyyText))
        {
            TekosyyMessage = "No tekosyy to save. Generate one first.";
            return RedirectToPage();
        }

        try
        {
            // Use API to get the current user's ID
            var client = _httpClientFactory.CreateClient();

            // Set BaseAddress dynamically
            var request = _httpContextAccessor.HttpContext.Request;
            var baseUrl = $"{request.Scheme}://{request.Host}";
            client.BaseAddress = new Uri(baseUrl);

            // First check if this is an admin user
            var adminResponse = await client.GetAsync($"/api/admin/{Uri.EscapeDataString(Username)}");
            bool isAdmin = adminResponse.IsSuccessStatusCode;
            
            int userId = 0;
            
            if (!isAdmin)
            {
                // Regular user - get user ID
                var userIdResponse = await client.GetAsync($"/api/user/{Uri.EscapeDataString(Username)}/id");

                if (!userIdResponse.IsSuccessStatusCode)
                {
                    TekosyyMessage = "Error: Could not identify current user.";
                    _logger.LogError("Failed to get user ID: {StatusCode}", userIdResponse.StatusCode);
                    return Page();
                }

                var userIdContent = await userIdResponse.Content.ReadAsStringAsync();
                userId = int.Parse(userIdContent);
            }
            else
            {
                // Admin user - since they don't have user IDs in the same way, we'll use a special value
                // that the API will recognize as belonging to an admin
                _logger.LogInformation("Admin user detected - using admin ID");
                userId = -1; // Special ID to indicate admin user
            }

            // Create a new tekosyy using the API
            var tekosyyDto = new
            {
                Tekosyy = tekosyyText,
                UserId = userId,
                Tyyppi = isAdmin ? "Admin-Generated" : "AI-Generated"
            };

            var tekosyyContent = new StringContent(
                JsonConvert.SerializeObject(tekosyyDto),
                Encoding.UTF8,
                "application/json"
            );

            var response = await client.PostAsync("/api/tekosyy", tekosyyContent);

            if (response.IsSuccessStatusCode)
            {
                AIResponse = tekosyyText; // Preserve the saved excuse in AIResponse field
                TekosyyMessage = "Tekosyy saved successfully!";
                UserInput = null; // Clear the input field after successful save
            }
            else
            {
                var errorResponse = await response.Content.ReadAsStringAsync();
                _logger.LogError("Failed to save tekosyy: {StatusCode}, {Response}",
                    response.StatusCode, errorResponse);
                TekosyyMessage = $"Error saving tekosyy: {response.StatusCode}";
                AIResponse = tekosyyText; // Preserve the generated excuse even if save failed
                // Keep UserInput in this case so user can see what failed
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception while saving tekosyy");
            TekosyyMessage = $"Error: {ex.Message}";
            AIResponse = tekosyyText; // Preserve the generated excuse on exception
            // Keep UserInput in this case so user can see what failed
        }

        return RedirectToPage(); // Redirect after handling the post
    }

    public async Task<IActionResult> OnPostSaveTekosyyWithRatingAsync(string tekosyyText, int achievementPoints)
    {
        Username = HttpContext.Session.GetString("Username");
        if (string.IsNullOrEmpty(Username))
        {
            return RedirectToPage("/Login");
        }

        if (string.IsNullOrEmpty(tekosyyText))
        {
            TekosyyMessage = "No tekosyy to save. Generate one first.";
            return RedirectToPage();
        }

        try
        {
            // Use API to get the current user's ID
            var client = _httpClientFactory.CreateClient();

            // Set BaseAddress dynamically
            var request = _httpContextAccessor.HttpContext.Request;
            var baseUrl = $"{request.Scheme}://{request.Host}";
            client.BaseAddress = new Uri(baseUrl);

            // First check if this is an admin user
            var adminResponse = await client.GetAsync($"/api/admin/{Uri.EscapeDataString(Username)}");
            bool isAdmin = adminResponse.IsSuccessStatusCode;
            
            int userId = 0;
            
            if (!isAdmin)
            {
                // Regular user - get user ID
                var userIdResponse = await client.GetAsync($"/api/user/{Uri.EscapeDataString(Username)}/id");

                if (!userIdResponse.IsSuccessStatusCode)
                {
                    TekosyyMessage = "Error: Could not identify current user.";
                    _logger.LogError("Failed to get user ID: {StatusCode}", userIdResponse.StatusCode);
                    return Page();
                }

                var userIdContent = await userIdResponse.Content.ReadAsStringAsync();
                userId = int.Parse(userIdContent);
            }
            else
            {
                // Admin user - since they don't have user IDs in the same way, we'll use a special value
                // that the API will recognize as belonging to an admin
                _logger.LogInformation("Admin user detected - using admin ID");
                userId = -1; // Special ID to indicate admin user
            }

            // Apply bounds to achievement points (1-10)
            if (achievementPoints < 0) achievementPoints = 0;
            if (achievementPoints > 10) achievementPoints = 10;

            // Create a new tekosyy using the API
            var tekosyyDto = new
            {
                Tekosyy = tekosyyText,
                UserId = userId,
                Tyyppi = isAdmin ? "Admin-Generated" : "AI-Generated",
                AchievementPoints = achievementPoints
            };

            var tekosyyContent = new StringContent(
                JsonConvert.SerializeObject(tekosyyDto),
                Encoding.UTF8,
                "application/json"
            );

            var response = await client.PostAsync("/api/tekosyy", tekosyyContent);

            if (response.IsSuccessStatusCode)
            {
                AIResponse = tekosyyText; // Preserve the saved excuse in AIResponse field
                TekosyyMessage = "Tekosyy saved successfully!";
                UserInput = null; // Clear the input field after successful save
            }
            else
            {
                var errorResponse = await response.Content.ReadAsStringAsync();
                _logger.LogError("Failed to save tekosyy: {StatusCode}, {Response}",
                    response.StatusCode, errorResponse);
                TekosyyMessage = $"Error saving tekosyy: {response.StatusCode}";
                AIResponse = tekosyyText; // Preserve the generated excuse even if save failed
                // Keep UserInput in this case so user can see what failed
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception while saving tekosyy");
            TekosyyMessage = $"Error: {ex.Message}";
            AIResponse = tekosyyText; // Preserve the generated excuse on exception
            // Keep UserInput in this case so user can see what failed
        }

        return RedirectToPage(); // Redirect after handling the post
    }

    private async Task<string> GetGeminiAIResponse(string userInput)
    {
        try
        {
            var client = _httpClientFactory.CreateClient();
            var apiKey = _configuration["GeminiAI:ApiKey"];
            var endpoint = _configuration["GeminiAI:Endpoint"];

            // Optimize the prompt to use fewer tokens
            var request = new
            {
                contents = new[]
                {
                    // Condensed system instructions
                    new {
                        parts = new[]
                        {
                         new { text = 
                            "Luo lyhyt ja uskottava tekosyy käyttäjän tilanteeseen. Keksi TÄYSIN UNIIKKI tekosyy joka eroaa aiemmista. Käytä luovuutta ja vaihtele tekosyiden teemoja. Älä toista aiempia ideoita tai rakenteita." }
                        },
                        role = "model"
                    },
                    // User input
                    new {
                        parts = new[]
                        {
                            new { text = userInput }
                        },
                        role = "user"
                    }
                },
                generationConfig = new
                {
                    maxOutputTokens = 150,
                    temperature = 0.9,  // Increased from 0.7 to 0.9 for more variation
                    topP = 0.95         // Increased from 0.8 to 0.95 for more diversity
                }
            };

            var json = JsonConvert.SerializeObject(request);
            _logger.LogInformation("Sending Gemini Request: {JsonPayload}", json); // Log request
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync($"{endpoint}?key={apiKey}", content);

            var responseBody = await response.Content.ReadAsStringAsync();
            _logger.LogInformation("Received Gemini Response: {StatusCode} - {ResponseBody}", response.StatusCode, responseBody); // Log response

            if (response.IsSuccessStatusCode)
            {
                try // Add try-catch around parsing
                {
                    var parsed = System.Text.Json.JsonDocument.Parse(responseBody);
                    var resultText = parsed.RootElement
                        .GetProperty("candidates")[0]
                        .GetProperty("content")
                        .GetProperty("parts")[0]
                        .GetProperty("text")
                        .GetString();
                    return resultText;
                }
                catch (Exception parseEx)
                {
                    _logger.LogError(parseEx, "Error parsing Gemini response: {ResponseBody}", responseBody);
                    return "Virhe AI-vastauksen jäsentämisessä.";
                }
            }
            else
            {
                // Log error already handled here by previous logging
                _logger.LogError("Gemini API error: {StatusCode}", response.StatusCode);
                return "Virhe AI-vastauksessa. Yritä myöhemmin uudelleen.";
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Virhe Gemini AI -integraatiossa");
            return "Tekninen virhe AI-vastauksen luonnissa.";
        }
    }

}
