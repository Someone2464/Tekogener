using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;

namespace Tekosyy_Generaattori.Pages
{
    public class LogoutModel : PageModel
    {
        public string LogoutMessage { get; set; } = "Sinut on kirjattu ulos onnistuneesti.";

        public IActionResult OnGet()
        {
            // Clear the session
            HttpContext.Session.Clear();
            
            // Set a temporary message in TempData that can be accessed on the Login page
            TempData["LogoutMessage"] = LogoutMessage;
            
            // Return the page first to show the message
            return Page();
        }
        
        // After showing the message, redirect to login
        public IActionResult OnPost()
        {
            return RedirectToPage("/Login");
        }
    }
}