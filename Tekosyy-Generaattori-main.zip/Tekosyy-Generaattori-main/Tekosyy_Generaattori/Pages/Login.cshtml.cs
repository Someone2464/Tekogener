using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;

public class LoginModel : PageModel
{
    private readonly UserService _userService;

    private readonly AdminService _adminService;

    public LoginModel(UserService userService, AdminService adminService)
    {
        _userService = userService;
        _adminService = adminService;
    }

    [BindProperty]
    public string Username { get; set; } = string.Empty;

    [BindProperty]
    public string Password { get; set; } = string.Empty;

    public string LoginMessage { get; set; } = string.Empty;

    public void OnGet()
    {
        // Check if there's a logout message in TempData
        if (TempData["LogoutMessage"] != null)
        {
            LoginMessage = TempData["LogoutMessage"].ToString();
        }
    }

    public IActionResult OnPost()
    {
        if (string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(Password))
        {
            LoginMessage = "Username and password cannot be empty.";
            return Page();
        }

        // Check if credentials match a regular user
        if (_userService.ValidateUser(Username, Password))
        {
            // Store username in both session variables for compatibility
            HttpContext.Session.SetString("Username", Username);
            HttpContext.Session.SetString("User", Username);

            // Redirect to TekosyyGeneraattori as requested
            return RedirectToPage("/TekosyyGeneraattori");
        }

        // If not a regular user, check if it's an admin
        else if (_adminService.ValidateAdmin(Username, Password))
        {
            HttpContext.Session.SetString("Username", Username);
            HttpContext.Session.SetString("User", Username);
            HttpContext.Session.SetString("IsAdmin", "true"); // Mark as admin in session
            return RedirectToPage("/AdminDashboard");
        }

        else
        {
            LoginMessage = "Invalid username or password.";
            return Page();
        }
    }
}