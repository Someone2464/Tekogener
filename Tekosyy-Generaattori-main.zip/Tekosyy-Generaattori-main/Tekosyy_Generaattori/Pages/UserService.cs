using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

public class UserService
{
    private readonly string _connectionString = "Data Source=database.db;Version=3;";
    private readonly ILogger<UserService> _logger;

    public UserService(ILogger<UserService> logger)
    {
        _logger = logger;
    }

    public bool AddUser(string username, string password)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO Kayttajat (user, password) VALUES (@user, @password)";

                using (var command = new SQLiteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@user", username);
                    command.Parameters.AddWithValue("@password", password);

                    int result = command.ExecuteNonQuery();
                    return result > 0;
                }
            }
        }
        catch (SQLiteException ex)
        {
            _logger.LogError($"Error adding user: {ex.Message}");
            return false;
        }
    }

    public async Task<UserResult> AddUserAsync(string username, string password)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();

                string insertQuery = "INSERT INTO Kayttajat (user, password) VALUES (@user, @password); SELECT last_insert_rowid();";

                using (var command = new SQLiteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@user", username);
                    command.Parameters.AddWithValue("@password", password);

                    int newId = Convert.ToInt32(await command.ExecuteScalarAsync());

                    return new UserResult
                    {
                        Success = true,
                        User = new User
                        {
                            Id = newId,
                            Username = username
                        }
                    };
                }
            }
        }
        catch (SQLiteException ex)
        {
            _logger.LogError($"Error adding user: {ex.Message}");
            return new UserResult { Success = false, Message = "Username already exists" };
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error adding user: {ex.Message}");
            return new UserResult { Success = false, Message = $"An error occurred: {ex.Message}" };
        }
    }

    public bool ValidateUser(string username, string password)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM Kayttajat WHERE user = @user AND password = @password";

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@user", username);
                    command.Parameters.AddWithValue("@password", password);

                    int userExists = Convert.ToInt32(command.ExecuteScalar());
                    return userExists > 0;
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error validating user: {ex.Message}");
            return false;
        }
    }

    public async Task<UserResult> FindUserAsync(string username)
    {
        if (string.IsNullOrEmpty(username))
        {
            return new UserResult { Success = false, Message = "Username cannot be null or empty" };
        }

        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();
                string query = "SELECT id, user FROM Kayttajat WHERE user = @username";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return new UserResult
                            {
                                Success = true,
                                User = new User
                                {
                                    Id = Convert.ToInt32(reader["id"]),
                                    Username = reader["user"].ToString()
                                }
                            };
                        }
                        else
                        {
                            return new UserResult { Success = false, Message = "User not found" };
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error finding user: {ex.Message}");
            return new UserResult { Success = false, Message = "An error occurred while finding the user" };
        }
    }

    public async Task<UserIdResult> GetUserIdAsync(string username)
    {
        if (string.IsNullOrEmpty(username))
        {
            return new UserIdResult { Success = false, Message = "Username cannot be null or empty" };
        }

        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();
                string query = "SELECT id FROM Kayttajat WHERE user = @username";

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    var result = await command.ExecuteScalarAsync();

                    if (result != null && result != DBNull.Value)
                    {
                        return new UserIdResult
                        {
                            Success = true,
                            UserId = Convert.ToInt32(result)
                        };
                    }
                    else
                    {
                        return new UserIdResult { Success = false, Message = "User not found" };
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error getting user ID: {ex.Message}");
            return new UserIdResult { Success = false, Message = $"An error occurred: {ex.Message}" };
        }
    }

    public async Task<IEnumerable<UserDto>> GetAllUsersAsync()
    {
        var users = new List<UserDto>();

        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();
                string query = "SELECT id, user FROM Kayttajat";

                using (var command = new SQLiteCommand(query, connection))
                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        users.Add(new UserDto
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            Username = reader["user"].ToString()
                        });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error retrieving users: {ex.Message}");
        }

        return users;
    }

    public async Task<UserResult> UpdateUserAsync(string username, string newPassword)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Tarkista ensin onko käyttäjä olemassa
                string checkQuery = "SELECT COUNT(*) FROM Kayttajat WHERE user = @username";
                using (var checkCommand = new SQLiteCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@username", username);
                    int exists = Convert.ToInt32(await checkCommand.ExecuteScalarAsync());

                    if (exists == 0)
                    {
                        return new UserResult { Success = false, Message = "User not found" };
                    }
                }

                string updateQuery = "UPDATE Kayttajat SET password = @password WHERE user = @username";
                using (var command = new SQLiteCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", newPassword);

                    await command.ExecuteNonQueryAsync();
                    return new UserResult { Success = true };
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error updating user: {ex.Message}");
            return new UserResult { Success = false, Message = $"An error occurred: {ex.Message}" };
        }
    }

    public async Task<UserResult> DeleteUserAsync(string username)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Tarkista ensin onko käyttäjä olemassa
                string checkQuery = "SELECT COUNT(*) FROM Kayttajat WHERE user = @username";
                using (var checkCommand = new SQLiteCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@username", username);
                    int exists = Convert.ToInt32(await checkCommand.ExecuteScalarAsync());

                    if (exists == 0)
                    {
                        return new UserResult { Success = false, Message = "User not found" };
                    }
                }

                string deleteQuery = "DELETE FROM Kayttajat WHERE user = @username";
                using (var command = new SQLiteCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@username", username);

                    await command.ExecuteNonQueryAsync();
                    return new UserResult { Success = true };
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error deleting user: {ex.Message}");
            return new UserResult { Success = false, Message = $"An error occurred: {ex.Message}" };
        }
    }

    public class UserResult
    {
        public bool Success { get; set; }
        public User User { get; set; }
        public string Message { get; set; }
    }

    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
    }

    public class UserIdResult
    {
        public bool Success { get; set; }
        public int UserId { get; set; }
        public string Message { get; set; }
    }
}