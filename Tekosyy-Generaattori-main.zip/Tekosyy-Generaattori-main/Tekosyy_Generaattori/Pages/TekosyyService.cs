using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

public class TekosyyService
{
    private readonly string _connectionString = "Data Source=database.db;Version=3;";
    private readonly ILogger<TekosyyService> _logger;

    public TekosyyService(ILogger<TekosyyService> logger)
    {
        _logger = logger;
    }

    public async Task<IEnumerable<TekosyyDto>> GetAllTekosyytAsync()
    {
        var tekosyyt = new List<TekosyyDto>();

        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();
                string query = "SELECT * FROM Tekosyyt";

                using (var command = new SQLiteCommand(query, connection))
                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        tekosyyt.Add(new TekosyyDto
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            Tekosyy = reader["tekosyy"].ToString(),
                            UserId = Convert.ToInt32(reader["user_id"]),
                            AchievementPoints = Convert.ToInt32(reader["achievement_points"]),
                            Tyyppi = reader["tyyppi"].ToString()
                        });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error retrieving tekosyyt: {ex.Message}");
        }

        return tekosyyt;
    }

    public async Task<TekosyyResult> GetTekosyyByIdAsync(int id)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();
                string query = "SELECT * FROM Tekosyyt WHERE id = @id";

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return new TekosyyResult
                            {
                                Success = true,
                                Tekosyy = new TekosyyDto
                                {
                                    Id = Convert.ToInt32(reader["id"]),
                                    Tekosyy = reader["tekosyy"].ToString(),
                                    UserId = Convert.ToInt32(reader["user_id"]),
                                    AchievementPoints = Convert.ToInt32(reader["achievement_points"]),
                                    Tyyppi = reader["tyyppi"].ToString()
                                }
                            };
                        }

                        return new TekosyyResult
                        {
                            Success = false,
                            Message = "Tekosyy not found"
                        };
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error retrieving tekosyy: {ex.Message}");
            return new TekosyyResult
            {
                Success = false,
                Message = $"An error occurred: {ex.Message}"
            };
        }
    }

    public async Task<TekosyyResult> AddTekosyyAsync(string tekosyy, int userId, string tyyppi, int achievementPoints = 0)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Special case for Admin users (userId = -1)
                if (userId != -1)
                {
                    // Only check user existence for regular users (not admins)
                    string userCheckQuery = "SELECT COUNT(*) FROM Kayttajat WHERE id = @userId";
                    using (var checkCommand = new SQLiteCommand(userCheckQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@userId", userId);
                        int userExists = Convert.ToInt32(await checkCommand.ExecuteScalarAsync());

                        if (userExists == 0)
                        {
                            return new TekosyyResult
                            {
                                Success = false,
                                Message = "User not found"
                            };
                        }
                    }
                }
                else
                {
                    // For admin users, log the special handling
                    _logger.LogInformation("Admin user (ID: -1) saving tekosyy, bypassing user validation");
                }

                // Ensure achievement points are within valid range
                if (achievementPoints < 0) achievementPoints = 0;
                if (achievementPoints > 10) achievementPoints = 10;

                string insertQuery = @"
                    INSERT INTO Tekosyyt (tekosyy, user_id, achievement_points, tyyppi) 
                    VALUES (@tekosyy, @userId, @achievementPoints, @tyyppi);
                    SELECT last_insert_rowid();";

                using (var command = new SQLiteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@tekosyy", tekosyy);
                    command.Parameters.AddWithValue("@userId", userId);
                    command.Parameters.AddWithValue("@achievementPoints", achievementPoints);
                    command.Parameters.AddWithValue("@tyyppi", tyyppi);

                    int newId = Convert.ToInt32(await command.ExecuteScalarAsync());

                    return new TekosyyResult
                    {
                        Success = true,
                        Tekosyy = new TekosyyDto
                        {
                            Id = newId,
                            Tekosyy = tekosyy,
                            UserId = userId,
                            AchievementPoints = achievementPoints,
                            Tyyppi = tyyppi
                        }
                    };
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error adding tekosyy: {ex.Message}");
            return new TekosyyResult
            {
                Success = false,
                Message = $"An error occurred: {ex.Message}"
            };
        }
    }

    public async Task<TekosyyResult> UpdateTekosyyAsync(int id, string tekosyy, string tyyppi)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Check if tekosyy exists
                string checkQuery = "SELECT COUNT(*) FROM Tekosyyt WHERE id = @id";
                using (var checkCommand = new SQLiteCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@id", id);
                    int exists = Convert.ToInt32(await checkCommand.ExecuteScalarAsync());

                    if (exists == 0)
                    {
                        return new TekosyyResult
                        {
                            Success = false,
                            Message = "Tekosyy not found"
                        };
                    }
                }

                string updateQuery = "UPDATE Tekosyyt SET tekosyy = @tekosyy, tyyppi = @tyyppi WHERE id = @id";

                using (var command = new SQLiteCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@tekosyy", tekosyy);
                    command.Parameters.AddWithValue("@tyyppi", tyyppi);
                    command.Parameters.AddWithValue("@id", id);

                    await command.ExecuteNonQueryAsync();

                    return new TekosyyResult
                    {
                        Success = true
                    };
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error updating tekosyy: {ex.Message}");
            return new TekosyyResult
            {
                Success = false,
                Message = $"An error occurred: {ex.Message}"
            };
        }
    }

    public async Task<TekosyyResult> DeleteTekosyyAsync(int id)
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Check if tekosyy exists
                string checkQuery = "SELECT COUNT(*) FROM Tekosyyt WHERE id = @id";
                using (var checkCommand = new SQLiteCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@id", id);
                    int exists = Convert.ToInt32(await checkCommand.ExecuteScalarAsync());

                    if (exists == 0)
                    {
                        return new TekosyyResult
                        {
                            Success = false,
                            Message = "Tekosyy not found"
                        };
                    }
                }

                string deleteQuery = "DELETE FROM Tekosyyt WHERE id = @id";

                using (var command = new SQLiteCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    await command.ExecuteNonQueryAsync();

                    return new TekosyyResult
                    {
                        Success = true
                    };
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error deleting tekosyy: {ex.Message}");
            return new TekosyyResult
            {
                Success = false,
                Message = $"An error occurred: {ex.Message}"
            };
        }
    }

    public class TekosyyResult
    {
        public bool Success { get; set; }
        public TekosyyDto Tekosyy { get; set; }
        public string Message { get; set; }
    }
}