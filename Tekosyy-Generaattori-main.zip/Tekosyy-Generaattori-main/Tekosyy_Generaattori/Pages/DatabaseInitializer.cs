using System;
using System.Data.SQLite;
using Microsoft.Extensions.Logging;

public class DatabaseInitializer
{
    private readonly string _connectionString = "Data Source=database.db;Version=3;";
    private readonly ILogger<DatabaseInitializer> _logger;

    public DatabaseInitializer(ILogger<DatabaseInitializer> logger)
    {
        _logger = logger;
    }

    public void InitializeDatabase()
    {
        try
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                // Kayttajat-taulun luonti
                string createUsersTable = @"
                    CREATE TABLE IF NOT EXISTS Kayttajat (
                        id INTEGER PRIMARY KEY AUTOINCREMENT, 
                        user TEXT UNIQUE NOT NULL, 
                        password TEXT NOT NULL
                    );";
                ExecuteCommand(connection, createUsersTable);
                _logger.LogInformation("Kayttajat-taulu tarkistettu tai luotu.");

                // Admins-taulun luonti
                string createAdminsTable = @"
                    CREATE TABLE IF NOT EXISTS Admins (
                        id INTEGER PRIMARY KEY AUTOINCREMENT, 
                        user TEXT UNIQUE NOT NULL, 
                        password TEXT NOT NULL
                    );";
                ExecuteCommand(connection, createAdminsTable);
                _logger.LogInformation("Admins-taulu tarkistettu tai luotu.");

                // Check if the old Tekosyyt table exists with foreign key constraint
                bool tableExists = CheckIfTableExists(connection, "Tekosyyt");
                if (tableExists)
                {
                    // Rename the old table to backup
                    string renameTekosyytTable = "ALTER TABLE Tekosyyt RENAME TO Tekosyyt_old;";
                    ExecuteCommand(connection, renameTekosyytTable);
                    _logger.LogInformation("Existing Tekosyyt table renamed to Tekosyyt_old");
                }

                // Create new Tekosyyt table without the foreign key constraint
                string createExcusesTable = @"
                    CREATE TABLE IF NOT EXISTS Tekosyyt (
                        id INTEGER PRIMARY KEY AUTOINCREMENT, 
                        tekosyy TEXT NOT NULL, 
                        user_id INTEGER NOT NULL, 
                        achievement_points INTEGER DEFAULT 0, 
                        tyyppi TEXT NOT NULL
                    );";
                ExecuteCommand(connection, createExcusesTable);
                _logger.LogInformation("Tekosyyt-taulu luotu ilman foreign key -rajoitetta.");

                // If old table existed, copy data from it
                if (tableExists)
                {
                    string copyData = @"
                        INSERT INTO Tekosyyt (id, tekosyy, user_id, achievement_points, tyyppi)
                        SELECT id, tekosyy, user_id, achievement_points, tyyppi FROM Tekosyyt_old;";
                    ExecuteCommand(connection, copyData);
                    _logger.LogInformation("Data copied from old Tekosyyt table.");

                    // Drop the old table
                    string dropOldTable = "DROP TABLE Tekosyyt_old;";
                    ExecuteCommand(connection, dropOldTable);
                    _logger.LogInformation("Old Tekosyyt table dropped.");
                }

                _logger.LogInformation("Tietokanta alustettu onnistuneesti.");

                // Create special user for admins if needed
                string checkAdminUserExists = "SELECT COUNT(*) FROM Kayttajat WHERE id = -1;";
                using (var command = new SQLiteCommand(checkAdminUserExists, connection))
                {
                    long count = (long)command.ExecuteScalar();
                    if (count == 0)
                    {
                        // Insert special user for admin in Kayttajat table
                        string insertAdminUser = "INSERT OR IGNORE INTO Kayttajat (id, user, password) VALUES (-1, 'AdminUser', 'AdminPassword');";
                        ExecuteCommand(connection, insertAdminUser);
                        _logger.LogInformation("Special user for admin created in Kayttajat table.");
                    }
                    else
                    {
                        _logger.LogInformation("Special admin user already exists in Kayttajat table.");
                    }
                }

                string checkAdminExists = "SELECT COUNT(*) FROM Admins WHERE user = 'Admin';";
                using (var command = new SQLiteCommand(checkAdminExists, connection))
                {
                    long count = (long)command.ExecuteScalar();
                    if (count == 0)
                    {
                        string insertDefaultAdmin = "INSERT INTO Admins (user, password) VALUES ('Admin', 'Admin');";
                        ExecuteCommand(connection, insertDefaultAdmin);
                        _logger.LogInformation("Oletus Admin-käyttäjä lisätty.");
                    }
                    else
                    {
                        _logger.LogInformation("Oletus Admin-käyttäjä on jo olemassa.");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Tietokannan alustus epäonnistui: {ex.Message}");
        }
    }

    private bool CheckIfTableExists(SQLiteConnection connection, string tableName)
    {
        try
        {
            string query = $"SELECT name FROM sqlite_master WHERE type='table' AND name='{tableName}';";
            using (var command = new SQLiteCommand(query, connection))
            {
                var result = command.ExecuteScalar();
                return result != null;
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error checking if table exists: {ex.Message}");
            return false;
        }
    }

    private void ExecuteCommand(SQLiteConnection connection, string sql)
    {
        try
        {
            using (var command = new SQLiteCommand(sql, connection))
            {
                command.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"SQL-komennon suoritus epäonnistui: {ex.Message}\nKomento: {sql}");
        }
    }
}
